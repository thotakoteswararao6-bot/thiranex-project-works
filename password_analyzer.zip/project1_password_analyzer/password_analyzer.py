"""
Password Strength Analyzer
---------------------------
Checks a password's length, complexity, and uniqueness (against a common
password list and, optionally, a local history database), scores it,
and suggests a stronger alternative if it's weak.

Run:
    python password_analyzer.py
"""

import re
import math
import sqlite3
import hashlib
import secrets
import string
from datetime import datetime

DB_FILE = "password_history.db"

# A small sample of extremely common passwords (in a real project, load a
# bigger list from a file like rockyou.txt or the "10k-most-common" list).
COMMON_PASSWORDS = {
    "password", "123456", "123456789", "qwerty", "abc123", "password1",
    "111111", "12345678", "letmein", "iloveyou", "admin", "welcome",
    "monkey", "dragon", "football", "123123", "sunshine", "master",
}


# --------------------------------------------------------------------------
# Database (optional feature: prevent reuse of old passwords)
# --------------------------------------------------------------------------
def init_db():
    conn = sqlite3.connect(DB_FILE)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS password_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    conn.commit()
    return conn


def hash_password(password: str) -> str:
    # SHA-256 is fine here since we're only using it to detect *reuse*,
    # not to store a live login credential. For real login systems, use
    # a slow hash like bcrypt/Argon2/PBKDF2 (see Project 2).
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def is_password_reused(conn, username: str, password: str) -> bool:
    pw_hash = hash_password(password)
    cur = conn.execute(
        "SELECT 1 FROM password_history WHERE username = ? AND password_hash = ?",
        (username, pw_hash),
    )
    return cur.fetchone() is not None


def save_password_to_history(conn, username: str, password: str):
    conn.execute(
        "INSERT INTO password_history (username, password_hash, created_at) VALUES (?, ?, ?)",
        (username, hash_password(password), datetime.utcnow().isoformat()),
    )
    conn.commit()


# --------------------------------------------------------------------------
# Strength analysis
# --------------------------------------------------------------------------
def calculate_entropy(password: str) -> float:
    """Rough entropy estimate in bits: length * log2(pool size)."""
    pool = 0
    if re.search(r"[a-z]", password):
        pool += 26
    if re.search(r"[A-Z]", password):
        pool += 26
    if re.search(r"[0-9]", password):
        pool += 10
    if re.search(r"[^a-zA-Z0-9]", password):
        pool += 32
    if pool == 0:
        return 0.0
    return len(password) * math.log2(pool)


def analyze_password(password: str) -> dict:
    checks = {
        "length_ok": len(password) >= 12,
        "has_lower": bool(re.search(r"[a-z]", password)),
        "has_upper": bool(re.search(r"[A-Z]", password)),
        "has_digit": bool(re.search(r"[0-9]", password)),
        "has_special": bool(re.search(r"[^a-zA-Z0-9]", password)),
        "no_common_pattern": not bool(re.search(r"(.)\1{2,}", password)),  # aaa, 111
        "not_common_password": password.lower() not in COMMON_PASSWORDS,
        "not_sequential": not has_sequential_chars(password),
    }

    score = sum(checks.values())  # out of 8
    entropy = calculate_entropy(password)

    if score <= 3 or entropy < 28:
        rating = "Very Weak"
    elif score <= 5 or entropy < 36:
        rating = "Weak"
    elif score <= 6 or entropy < 60:
        rating = "Moderate"
    elif score == 7 or entropy < 80:
        rating = "Strong"
    else:
        rating = "Very Strong"

    return {"checks": checks, "score": score, "entropy": entropy, "rating": rating}


def has_sequential_chars(password: str, run_length: int = 3) -> bool:
    """Detects ascending/descending runs like 'abcd' or '4321'."""
    lower = password.lower()
    for i in range(len(lower) - run_length + 1):
        chunk = lower[i:i + run_length]
        if all(ord(chunk[j + 1]) - ord(chunk[j]) == 1 for j in range(len(chunk) - 1)):
            return True
        if all(ord(chunk[j]) - ord(chunk[j + 1]) == 1 for j in range(len(chunk) - 1)):
            return True
    return False


def suggest_password(length: int = 16) -> str:
    """Generates a strong random password using the 'secrets' module
    (cryptographically secure, unlike 'random')."""
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*()-_=+"
    while True:
        pwd = "".join(secrets.choice(alphabet) for _ in range(length))
        # Make sure the generated password actually passes all our own checks
        result = analyze_password(pwd)
        if result["rating"] in ("Strong", "Very Strong"):
            return pwd


def print_report(password: str, result: dict):
    print("\n" + "=" * 50)
    print(f"Password Strength Report")
    print("=" * 50)
    print(f"Rating:  {result['rating']}")
    print(f"Score:   {result['score']} / 8")
    print(f"Entropy: {result['entropy']:.1f} bits")
    print("-" * 50)
    labels = {
        "length_ok": "At least 12 characters",
        "has_lower": "Contains lowercase letters",
        "has_upper": "Contains uppercase letters",
        "has_digit": "Contains digits",
        "has_special": "Contains special characters",
        "no_common_pattern": "No repeated character runs (aaa, 111)",
        "not_common_password": "Not a well-known common password",
        "not_sequential": "No sequential runs (abcd, 4321)",
    }
    for key, passed in result["checks"].items():
        mark = "PASS" if passed else "FAIL"
        print(f"[{mark}] {labels[key]}")
    print("=" * 50)


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------
def main():
    print("=== Password Strength Analyzer ===")
    use_history = input("Enable password-reuse checking (needs a username)? [y/N]: ").strip().lower() == "y"

    conn = None
    username = None
    if use_history:
        conn = init_db()
        username = input("Username: ").strip()

    password = input("Enter a password to analyze: ")

    if use_history and is_password_reused(conn, username, password):
        print("\n[!] This password matches one you've used before for this "
              "account. Please choose a different one.")
        return

    result = analyze_password(password)
    print_report(password, result)

    if result["rating"] in ("Very Weak", "Weak", "Moderate"):
        print("\nSuggested stronger alternatives:")
        for _ in range(3):
            print(f"  -> {suggest_password()}")

    if use_history and result["rating"] in ("Strong", "Very Strong"):
        save = input("\nSave this password to your history? [y/N]: ").strip().lower() == "y"
        if save:
            save_password_to_history(conn, username, password)
            print("Saved.")

    if conn:
        conn.close()


if __name__ == "__main__":
    main()
