"""
Phishing Email Detection Model
--------------------------------
Trains a classifier to label emails as "Phishing" or "Safe" using both
textual content (TF-IDF) and URL/keyword-based features.

Run:
    pip install -r requirements.txt
    python generate_dataset.py      # creates the sample dataset (once)
    python phishing_detector.py     # trains + evaluates the model
"""

import re
import numpy as np
import pandas as pd
from scipy.sparse import hstack, csr_matrix

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, confusion_matrix, classification_report, ConfusionMatrixDisplay
)
import matplotlib.pyplot as plt

DATA_FILE = "emails_dataset.csv"

# Keywords commonly seen in phishing attempts
SUSPICIOUS_KEYWORDS = [
    "verify", "urgent", "suspended", "click", "confirm", "password",
    "limited", "restricted", "update your", "account", "security alert",
    "winner", "prize", "free", "act now", "immediately", "claim",
]

URL_PATTERN = re.compile(r"https?://[^\s]+")
IP_URL_PATTERN = re.compile(r"https?://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}")


# --------------------------------------------------------------------------
# Feature engineering
# --------------------------------------------------------------------------
def extract_url_features(text: str) -> dict:
    urls = URL_PATTERN.findall(text)
    return {
        "num_urls": len(urls),
        "has_ip_url": 1 if IP_URL_PATTERN.search(text) else 0,
        "has_at_symbol": 1 if "@" in text and urls else 0,
        "avg_url_length": np.mean([len(u) for u in urls]) if urls else 0,
    }


def extract_keyword_features(text: str) -> dict:
    text_lower = text.lower()
    hits = sum(1 for kw in SUSPICIOUS_KEYWORDS if kw in text_lower)
    return {
        "suspicious_keyword_count": hits,
        "has_exclamation": 1 if "!" in text else 0,
        "all_caps_word_count": sum(1 for w in text.split() if w.isupper() and len(w) > 2),
    }


def build_feature_matrix(df: pd.DataFrame, vectorizer: TfidfVectorizer, fit: bool = False):
    # 1. TF-IDF on the raw email text
    if fit:
        tfidf_features = vectorizer.fit_transform(df["text"])
    else:
        tfidf_features = vectorizer.transform(df["text"])

    # 2. Structured URL + keyword features
    extra = df["text"].apply(lambda t: {**extract_url_features(t), **extract_keyword_features(t)})
    extra_df = pd.DataFrame(list(extra))
    extra_sparse = csr_matrix(extra_df.values)

    # 3. Combine both feature sets into one matrix
    combined = hstack([tfidf_features, extra_sparse])
    return combined, extra_df.columns.tolist()


# --------------------------------------------------------------------------
# Main pipeline
# --------------------------------------------------------------------------
def main():
    df = pd.read_csv(DATA_FILE)
    print(f"Loaded {len(df)} emails ({df['label'].sum()} phishing / {(df['label'] == 0).sum()} safe)")

    X_train_df, X_test_df, y_train, y_test = train_test_split(
        df, df["label"], test_size=0.25, random_state=42, stratify=df["label"]
    )

    vectorizer = TfidfVectorizer(max_features=500, stop_words="english")
    X_train, feature_names = build_feature_matrix(X_train_df, vectorizer, fit=True)
    X_test, _ = build_feature_matrix(X_test_df, vectorizer, fit=False)

    # RandomForest tends to do well with this mix of sparse text + dense features
    model = RandomForestClassifier(n_estimators=200, random_state=42)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)

    acc = accuracy_score(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred)

    print(f"\nAccuracy: {acc * 100:.2f}%\n")
    print("Classification Report:")
    print(classification_report(y_test, y_pred, target_names=["Safe", "Phishing"]))

    print("Confusion Matrix (rows = actual, cols = predicted):")
    print(cm)

    # Save a plotted confusion matrix
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Safe", "Phishing"])
    disp.plot(cmap="Blues", values_format="d")
    plt.title(f"Confusion Matrix (Accuracy: {acc * 100:.1f}%)")
    plt.tight_layout()
    plt.savefig("confusion_matrix.png")
    print("\nSaved confusion matrix plot to confusion_matrix.png")

    # Quick demo: classify a couple of new emails
    demo_emails = [
        "URGENT: Your account has been suspended, verify now at http://secure-verify-account.com/login",
        "Hi, just checking in about the report you were working on. Let me know if you need help.",
    ]
    demo_df = pd.DataFrame({"text": demo_emails})
    demo_X, _ = build_feature_matrix(demo_df, vectorizer, fit=False)
    demo_preds = model.predict(demo_X)
    print("\nDemo predictions:")
    for email, pred in zip(demo_emails, demo_preds):
        label = "Phishing" if pred == 1 else "Safe"
        print(f"  [{label}] {email[:70]}...")


if __name__ == "__main__":
    main()
