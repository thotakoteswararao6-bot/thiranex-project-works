"""
Generates a small sample dataset of phishing and legitimate emails for
demo/training purposes, and saves it to emails_dataset.csv.

NOTE: This is a synthetic sample so the project runs out of the box.
For a real assignment submission, swap this out for a real dataset, e.g.:
  - Kaggle: "Phishing Email Detection" / "Spam or Not Spam"
  - https://www.kaggle.com/datasets/subhajournal/phishingemails
Just make sure the CSV has a 'text' column and a 'label' column
(1 = phishing, 0 = legitimate) and point phishing_detector.py at it.
"""

import csv
import random

random.seed(42)

PHISHING_TEMPLATES = [
    "Dear customer, your account has been suspended. Verify now at http://{domain}/verify?id={num}",
    "URGENT: Unusual login detected. Confirm your identity immediately: http://{domain}/secure-login",
    "You have won a prize of $1000! Claim it now by clicking http://{domain}/claim-{num}",
    "Your payment could not be processed. Update your billing info here: http://{domain}/billing",
    "Security Alert: Your password will expire in 24 hours. Reset it now: http://{domain}/reset?token={num}",
    "Congratulations! You've been selected for a free gift card. Click http://{domain}/gift to redeem.",
    "Action required: Your PayPal account is limited. Restore access at http://{domain}/paypal-restore",
    "We noticed suspicious activity on your bank account. Verify your details: http://{domain}/bank-verify",
    "Your package could not be delivered. Reschedule here: http://{domain}/delivery?ref={num}",
    "IT Support: Your mailbox is full. Click http://{domain}/mailbox-upgrade to avoid service loss.",
    "Final notice: Your subscription payment failed. Update now at http://{domain}/subscription",
    "You have a new voicemail. Listen now: http://{domain}/voicemail-{num}",
]

LEGIT_TEMPLATES = [
    "Hi team, attaching the meeting notes from today's standup. Let me know if I missed anything.",
    "Reminder: Project review is scheduled for Friday at 3 PM in conference room B.",
    "Thanks for your order! Your invoice #{num} is attached for your records.",
    "Hey, are we still on for lunch tomorrow? Let me know what time works.",
    "Please find attached the quarterly report for review before Monday's meeting.",
    "Your monthly newsletter: here's what's new this month from our team.",
    "Following up on our call earlier, I've shared the document in the drive folder.",
    "Happy birthday! Hope you have a wonderful day, see you at the office party.",
    "The library book you requested, 'Deep Learning', is now available for pickup.",
    "Your flight itinerary for booking #{num} is confirmed. Departure is at 9 AM.",
    "Can you review the attached pull request when you get a chance? No rush.",
    "Reminder: Your dentist appointment is scheduled for next Tuesday at 10 AM.",
]

LEGIT_DOMAINS = ["company.com", "university.edu", "myshop.com", "airline.com"]
PHISHING_DOMAINS = ["secure-verify-account.com", "bank-alert-update.net", "login-confirm.info",
                    "paypal-restore-access.com", "free-gift-claim.biz", "192.168.1.1"]


def build_dataset(n_per_class: int = 60):
    rows = []
    for _ in range(n_per_class):
        template = random.choice(PHISHING_TEMPLATES)
        text = template.format(domain=random.choice(PHISHING_DOMAINS), num=random.randint(1000, 9999))
        rows.append({"text": text, "label": 1})

    for _ in range(n_per_class):
        template = random.choice(LEGIT_TEMPLATES)
        text = template.format(num=random.randint(1000, 9999)) if "{num}" in template else template
        rows.append({"text": text, "label": 0})

    random.shuffle(rows)
    return rows


def main():
    rows = build_dataset(60)
    with open("emails_dataset.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["text", "label"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {len(rows)} rows to emails_dataset.csv "
          f"({sum(r['label'] for r in rows)} phishing / {sum(1 - r['label'] for r in rows)} legit)")


if __name__ == "__main__":
    main()
