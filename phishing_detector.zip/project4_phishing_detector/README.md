# Phishing Email Detection Model

## Setup
```
pip install -r requirements.txt
python generate_dataset.py     # creates emails_dataset.csv (sample data)
python phishing_detector.py    # trains model, prints accuracy + confusion matrix
```

## Files
- `generate_dataset.py` — builds a small synthetic sample dataset (60 phishing + 60 legit emails)
  so the project runs immediately with no downloads.
- `phishing_detector.py` — extracts TF-IDF text features + URL/keyword features,
  trains a RandomForestClassifier, prints accuracy/classification report,
  and saves a confusion matrix plot to `confusion_matrix.png`.
- `emails_dataset.csv` — the generated sample dataset (regenerate anytime).

## IMPORTANT — before you submit
The included dataset is **synthetic and templated**, which is why accuracy comes
out at ~100%. That's an artifact of the sample data being too easy, not a sign
of a strong model. For a real submission, replace `emails_dataset.csv` with a
real-world phishing dataset such as:
- Kaggle: "Phishing Email Detection"
- Kaggle: "Spam or Not Spam"
- UCI: "Spambase" (with adaptation for phishing-style labels)

Just make sure your CSV has a `text` column and a `label` column
(1 = phishing, 0 = legitimate), and everything else in `phishing_detector.py`
will work unchanged. Expect real accuracy in the 90-97% range on a good
dataset — that's a much more meaningful result to report than 100%.

## How the features work
- **TF-IDF**: converts email text into weighted word-importance vectors.
- **URL features**: counts URLs, flags IP-based URLs (a common phishing red
  flag), flags "@" tricks in links.
- **Keyword features**: counts phishing-associated words ("verify", "urgent",
  "suspended", etc.), exclamation marks, and ALL-CAPS words.
