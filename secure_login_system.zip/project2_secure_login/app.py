"""
Secure Login System (Flask)
----------------------------
Features:
  - Registration & login with salted password hashes (Werkzeug's
    pbkdf2:sha256 by default — swap for bcrypt/argon2 if you install them)
  - Input validation on username/password
  - Parameterized SQL queries (no string-formatted SQL -> no SQL injection)
  - Session-based auth with logout
  - Optional TOTP-based 2FA (see the commented section near the bottom)

Run:
    pip install flask
    python app.py
Then visit http://127.0.0.1:5000
"""

import re
import sqlite3
from flask import Flask, request, redirect, url_for, session, render_template, flash
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "change-this-to-a-random-secret-in-production"  # use os.urandom(24)
DB_FILE = "users.db"

USERNAME_RE = re.compile(r"^[a-zA-Z0-9_]{3,20}$")


# --------------------------------------------------------------------------
# Database helpers
# --------------------------------------------------------------------------
def get_db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL
        )
        """
    )
    conn.commit()
    conn.close()


# --------------------------------------------------------------------------
# Validation
# --------------------------------------------------------------------------
def validate_username(username: str) -> str | None:
    if not USERNAME_RE.match(username):
        return "Username must be 3-20 characters: letters, numbers, underscore only."
    return None


def validate_password(password: str) -> str | None:
    if len(password) < 10:
        return "Password must be at least 10 characters long."
    if not re.search(r"[A-Z]", password):
        return "Password must contain an uppercase letter."
    if not re.search(r"[a-z]", password):
        return "Password must contain a lowercase letter."
    if not re.search(r"[0-9]", password):
        return "Password must contain a digit."
    if not re.search(r"[^a-zA-Z0-9]", password):
        return "Password must contain a special character."
    return None


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------
@app.route("/")
def home():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        error = validate_username(username) or validate_password(password)
        if error:
            flash(error, "error")
            return render_template("register.html")

        conn = get_db()
        existing = conn.execute(
            "SELECT id FROM users WHERE username = ?", (username,)  # parameterized -> no SQLi
        ).fetchone()
        if existing:
            flash("That username is already taken.", "error")
            conn.close()
            return render_template("register.html")

        password_hash = generate_password_hash(password)  # pbkdf2:sha256 with a random salt
        conn.execute(
            "INSERT INTO users (username, password_hash) VALUES (?, ?)",
            (username, password_hash),
        )
        conn.commit()
        conn.close()

        flash("Account created. Please log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        conn = get_db()
        user = conn.execute(
            "SELECT * FROM users WHERE username = ?", (username,)
        ).fetchone()
        conn.close()

        # check_password_hash handles the salt/verification; we deliberately
        # give the same generic error whether the username or password was
        # wrong, so an attacker can't tell which one failed.
        if user is None or not check_password_hash(user["password_hash"], password):
            flash("Invalid username or password.", "error")
            return render_template("login.html")

        session.clear()
        session["user_id"] = user["id"]
        session["username"] = user["username"]
        flash("Logged in successfully.", "success")
        return redirect(url_for("dashboard"))

    return render_template("login.html")


@app.route("/dashboard")
def dashboard():
    if "user_id" not in session:
        return redirect(url_for("login"))
    return render_template("dashboard.html", username=session["username"])


@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out.", "success")
    return redirect(url_for("login"))


# --------------------------------------------------------------------------
# OPTIONAL: Two-Factor Authentication (TOTP) sketch
# --------------------------------------------------------------------------
# To add 2FA:
#   pip install pyotp qrcode
#
#   import pyotp
#   # 1. On registration, generate a secret per user and store it:
#   totp_secret = pyotp.random_base32()
#   # save totp_secret in the users table
#
#   # 2. Show the user a QR code (via qrcode library) of:
#   pyotp.totp.TOTP(totp_secret).provisioning_uri(name=username, issuer_name="MyApp")
#   # They scan it with Google Authenticator / Authy.
#
#   # 3. On login, after password check succeeds, ask for the 6-digit code:
#   totp = pyotp.TOTP(user["totp_secret"])
#   if not totp.verify(request.form.get("otp_code")):
#       flash("Invalid 2FA code.", "error")
#       return render_template("login.html")
# --------------------------------------------------------------------------


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
